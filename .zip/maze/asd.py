import queue
q=queue.Queue(4)
q.put((1,2))
print(q.get())